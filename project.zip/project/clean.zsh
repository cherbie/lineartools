#!/bin/zsh
rm -f ./test/output/*
rm -f ./test/*.zip